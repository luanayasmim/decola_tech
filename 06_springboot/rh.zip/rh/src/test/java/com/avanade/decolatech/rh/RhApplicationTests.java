package com.avanade.decolatech.rh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RhApplicationTests {

	@Test
	void contextLoads() {
	}

}

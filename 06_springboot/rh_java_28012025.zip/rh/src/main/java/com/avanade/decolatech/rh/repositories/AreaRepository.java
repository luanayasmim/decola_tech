package com.avanade.decolatech.rh.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avanade.decolatech.rh.entities.Area;

public interface AreaRepository extends JpaRepository<Area, Integer>{

}
